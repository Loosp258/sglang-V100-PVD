nvidia-smi --query-gpu=index,memory.used --format=csv,noheader
