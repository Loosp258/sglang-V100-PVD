gzip -c -- /proj/llm-course-PG0/Yizhzhu-node2-sglang-pvd/validation/pvd-oasis-alignment-20261002/artifacts/oasis_delivery_slots_gate01/unit.txt
