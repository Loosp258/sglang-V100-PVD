$env:PYTHONPATH = (Join-Path $env:TEMP 'pvd-oasis-io-test-deps')
$ioTestCode = @'
import contextlib
import pathlib
import sys
import tempfile
import types
import uuid
root = pathlib.Path.cwd()
sys.path.insert(0, str(root / 'python'))
package = types.ModuleType('sglang')
package.__path__ = [str(root / 'python' / 'sglang')]
sys.modules['sglang'] = package
import pytest
base = pathlib.Path(tempfile.gettempdir()).resolve() / ('pvd-oasis-io-pytest-' + uuid.uuid4().hex)
assert base.parent == pathlib.Path(tempfile.gettempdir()).resolve()
log = pathlib.Path(tempfile.gettempdir()) / 'pvd_oasis_io_unit_final.txt'
with log.open('w', encoding='utf-8') as out, contextlib.redirect_stdout(out), contextlib.redirect_stderr(out):
    result = pytest.main(['-q', '--tb=short', '-p', 'no:cacheprovider', '--basetemp', str(base), 'test/registered/disaggregation/test_pvd_oasis_transport_io.py'])
print(log.read_text(encoding='utf-8'))
print('full_log=' + str(log))
raise SystemExit(result)
'@
python -B -c $ioTestCode
