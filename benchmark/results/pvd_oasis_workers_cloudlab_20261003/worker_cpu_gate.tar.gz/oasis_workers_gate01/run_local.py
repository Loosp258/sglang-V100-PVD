"""Re-run existing causal and lifecycle gates before a configuration-only trial."""
import contextlib
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import types

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
assert OUT.is_relative_to(ROOT / 'artifacts')
os.environ['TEMP'] = os.environ['TMP'] = str(OUT)
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
sys.path.insert(0, str(ROOT / 'artifacts/combined_rpc_agent01/deps'))
sys.path.insert(0, str(ROOT / 'python'))
package = types.ModuleType('sglang')
package.__path__ = [str(ROOT / 'python/sglang')]
sys.modules['sglang'] = package
import pytest

tests = ['test_pvd_oasis_attention.py', 'test_pvd_oasis_request.py',
         'test_pvd_oasis_pipeline.py', 'test_pvd_oasis_serving.py',
         'test_pvd_oasis_transport_io.py', 'test_pvd_oasis_receive_slot_records.py']
relative = ['python/sglang/srt/disaggregation/pvd/' + name for name in
            ('oasis_attention.py', 'oasis_pipeline.py', 'oasis_request.py',
             'oasis_transport.py', 'oasis_startup.py', 'oasis_receive_slots.py',
             'sparse_receiver.py', 'cuda_sparse_receiver.py', 'oasis_sglang.py')]
proof = {}
for name in relative:
    data = (ROOT / name).read_bytes().replace(b'\r\n', b'\n')
    frozen = subprocess.check_output(['git', '-c', f'safe.directory={ROOT.as_posix()}',
        '-C', str(ROOT), 'show', '9b8b5dc0c:' + name]).replace(b'\r\n', b'\n')
    assert data == frozen, ('serving source changed during config trial', name)
    proof[name] = hashlib.sha256(data).hexdigest()
(OUT / 'source_hashes.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8')
(OUT / 'scope.json').write_text(json.dumps(dict(
    frozen_serving_commit='9b8b5dc0c', tests=tests, new_mirror_tests=False,
    test_scope='existing CPU causal/lifecycle regressions; not native four-worker acceptance',
    gpu_used=False, ssh_used=False), indent=2) + '\n', encoding='utf-8')
with (OUT / 'unit.txt').open('w', encoding='utf-8') as log:
    with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        status = pytest.main(['-q', '--tb=short', '-p', 'no:cacheprovider', '--basetemp',
            str(OUT / 'tmp')] + [str(ROOT / 'test/registered/disaggregation' / test) for test in tests])
(OUT / 'status.json').write_text(json.dumps(dict(exit_code=status)) + '\n', encoding='utf-8')
print((OUT / 'unit.txt').read_text(encoding='utf-8'))
raise SystemExit(status)
