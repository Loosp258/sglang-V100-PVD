"""Offline evidence checks only; synthetic timestamps are not benchmark data."""
import copy
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
assert ROOT.name == "sglang-V100-PVD-oasiskv"
sys.path.insert(0, str(ROOT / "benchmark"))
from verify_pvd_oasis_latency_evidence import (
    callback_evidence, client_token_evidence, verify, worker_timing_evidence,
)
from preserve_pvd_oasis_delivery import worker_cpu_counts


def synthetic_request(workers, rid, case):
    layers, transport = [], [{"step": -1, "layer": layer} for layer in range(28)]
    forwards = [{"step": 0, "total_ms": 60.0, "wait_ms": 0.0}]
    cursor = 100.01
    times = [0.5, 0.56]
    for step in range(14):
        begin, wait = cursor, 0.0
        for layer in range(28):
            wave = (step * 28 + layer) // workers
            start, ready = 100 + wave * 0.04, 100 + (wave + 1) * 0.04
            wait_start = cursor
            consumed = max(cursor, ready) + 0.00001
            waited = consumed - cursor
            wait += waited
            layers.append(dict(step=step, layer=layer, published=start - 0.01,
                worker_start=start, ready=ready, consumed=consumed,
                queue_seconds=start - (start - 0.01), service_seconds=ready - start,
                consumer_wait_seconds=waited, ready_before_consume=ready <= wait_start))
            transport.append(dict(step=step, layer=layer))
            cursor = consumed + 0.001
        forwards.append(dict(step=step + 1, total_ms=(cursor - begin) * 1000,
                             wait_ms=wait * 1000))
        times.append(times[-1] + cursor - begin)
    row = dict(rid=rid, case=case, prompt_sha256="prompt", output_sha256="output",
        output_ids=list(range(16)), completion_tokens=16, first_event_seconds=times[0],
        wall_seconds=times[-1] + 0.01, forward=forwards,
        trace=dict(layers=layers, transport=transport))
    online = {name: row[name] for name in ("case", "prompt_sha256", "output_sha256",
        "completion_tokens", "first_event_seconds", "wall_seconds")}
    online.update(status=200, error=None, events=[dict(seconds=timestamp,
        event=dict(output_ids=row['output_ids'][:count],
            meta_info=dict(id=rid, completion_tokens=count)))
        for count, timestamp in enumerate(times, 1)])
    return row, online


checks = []
def checked(name, callback, rejects=False):
    try:
        callback()
    except (AssertionError, KeyError, ValueError):
        assert rejects, name
    else:
        assert not rejects, name
    checks.append(name)


two, two_online = synthetic_request(2, "synthetic_two", 1)
four, four_online = synthetic_request(4, "synthetic_four", 1)
for workers, row, online in ((2, two, two_online), (4, four, four_online)):
    result = callback_evidence(row['trace'], row['forward'], workers=workers)
    assert result['executor_peak'] == workers and abs(result['worker_occupancy'] - 1) < 1e-12
    assert abs(result['work_window_ms_per_token'] - 1120 / workers) < 1e-8
    client_token_evidence(row, online)
    checks.append(f"synthetic_{workers}_endpoint_capacity_and_actual_event_intervals")
checked("four_actual_callbacks_reject_two_capacity",
        lambda: callback_evidence(four['trace'], four['forward'], workers=2), True)
full, online = {'requests': {}}, {}
for arm in ('base_a', 'opt_a', 'opt_b', 'base_b'):
    pairs = [synthetic_request(4 if arm.startswith('opt') else 2, arm + str(case), case)
             for case in (1, 2)]
    full['requests'][arm] = [r for r, _ in pairs]
    online[arm] = [o for _, o in pairs]
checked("separate_two_four_mode_mean_median_and_occupancy",
        lambda: worker_timing_evidence(full, online, 'v-workers'))
wrong = copy.deepcopy(full)
wrong['requests']['opt_a'][0]['trace'] = copy.deepcopy(two['trace'])
wrong['requests']['opt_a'][0]['forward'] = copy.deepcopy(two['forward'])
checked("four_configuration_requires_actual_four_peak",
        lambda: worker_timing_evidence(wrong, online, 'v-workers'), True)
for name, field, value in (('nan_endpoint', 'ready', float('nan')),
                          ('forged_service', 'service_seconds', 0.001),
                          ('negative_queue', 'queue_seconds', -0.001)):
    broken = copy.deepcopy(four)
    broken['trace']['layers'][0][field] = value
    checked(name, lambda b=broken: callback_evidence(b['trace'], b['forward'], workers=4), True)
broken = copy.deepcopy(four)
broken['forward'][1]['wait_ms'] += 1
checked("forward_wait_must_match_actual_layer_wait_sum",
        lambda: callback_evidence(broken['trace'], broken['forward'], workers=4), True)
for name, mutate in (
    ('missing_token_event', lambda r: r['events'].pop()),
    ('changed_completion_progress', lambda r: r['events'][5]['event']['meta_info'].update(completion_tokens=7)),
    ('foreign_event_request', lambda r: r['events'][5]['event']['meta_info'].update(id='foreign')),
):
    broken = copy.deepcopy(four_online)
    mutate(broken)
    checked(name, lambda b=broken: client_token_evidence(four, b), True)
historical = []
for report in ('pvd_oasis_combined_delivery_cloudlab_20261002',
               'pvd_oasis_receive_slots_cloudlab_20261003'):
    folder = ROOT / 'benchmark/results' / report
    historical.append(dict(report=report, verification=verify(folder, check_git=True)))
    with tarfile.open(folder / 'raw.tar.gz') as tf:
        prefix = tf.getnames()[0].split('/')[0]
        full_raw = json.load(tf.extractfile(prefix + '/summary.json'))
        online_raw = json.load(tf.extractfile(prefix + '/online.json'))
    for arm, rows in full_raw['requests'].items():
        for row, actual in zip(rows, online_raw[arm]):
            assert callback_evidence(row['trace'], row['forward'], workers=2)['executor_peak'] == 2
            client_token_evidence(row, actual)
    checks.append(report + '_eight_real_request_events_and_callback_endpoints')
cpu = worker_cpu_counts(ROOT / 'artifacts/oasis_workers_gate01',
                        ROOT / 'artifacts/oasis_delivery_slots_gate01')
output = Path(__file__).resolve().parent / 'gate.json'
assert output.is_relative_to(ROOT / 'artifacts')
result = dict(status='passed', evidence_only=True, checks=checks,
              historical=historical, existing_worker_cpu_gate=cpu)
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(dict(status='passed', checks=len(checks), historical_reports=2,
                     output=str(output)), ensure_ascii=False))
