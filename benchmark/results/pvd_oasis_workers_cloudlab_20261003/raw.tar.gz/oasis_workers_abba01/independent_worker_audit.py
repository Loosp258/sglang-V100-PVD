"""Recompute the independent worker ABBA audit using only archived raw files.

Run with Python's standard library. The JSON is written beside this script,
within the owning checkout's artifacts directory; no serving code is imported.
Full V search scope is 840 calls/request. Steady scope excludes the first 56
initial-bank calls and contains 784 calls = 392 callbacks * two V ranks.
"""

from __future__ import annotations

import ast
import hashlib
import json
import math
from pathlib import Path
import re
from statistics import mean, median


FOLDER = Path(__file__).resolve().parent
ARMS = ("base_a", "opt_a", "opt_b", "base_b")
TIMINGS = (
    "prepare_seconds", "allocate_seconds", "register_seconds", "reserve_seconds",
    "start_seconds", "combined_seconds", "poll_seconds", "ack_seconds",
    "close_seconds", "cache_copy_seconds",
)
COUNTERS = {
    "physical_register_calls": "registration_count",
    "physical_unregister_calls": "unregistration_count",
    "reserve_calls": "reserve_rpc_count", "start_calls": "start_rpc_count",
    "combined_calls": "combined_rpc_count", "poll_calls": "poll_rpc_count",
    "ack_calls": "ack_rpc_count",
}
V_FIELDS = (
    "batch_total", "manager_lock", "candidate_download", "thread_wait",
    "workspace_lock", "native_submit", "native_completion", "query_place",
    "finite_proof",
)
D_SEARCH = re.compile(
    r"PVD D search-batch items=2 query_rows=14 bytes=(\d+) "
    r"prepare_ms=([0-9.]+) encode_ms=([0-9.]+) http_ms=([0-9.]+) "
    r"validate_ms=([0-9.]+) total_ms=([0-9.]+)"
)


def checked_output() -> Path:
    artifacts = next((p for p in FOLDER.parents if p.name == "artifacts"), None)
    assert artifacts is not None, "audit must live in a project artifacts directory"
    project = artifacts.parent.resolve()
    assert (project / "python" / "sglang").is_dir(), "owning project not found"
    target = (FOLDER / "independent_worker_audit.json").resolve()
    assert target.is_relative_to(project), "output outside owning project"
    return target


def read_json(name):
    return json.loads((FOLDER / name).read_text(encoding="utf-8"))


def integer(value, *, minimum=0):
    assert type(value) is int and value >= minimum
    return value


def finite(value):
    assert type(value) in (int, float) and math.isfinite(value) and value >= 0
    return value


def stats(values):
    values = list(values)
    assert values
    return {"count": len(values), "mean": mean(values), "median": median(values),
            "p95": sorted(values)[math.ceil(0.95 * len(values)) - 1],
            "minimum": min(values), "maximum": max(values)}


def v_stats(rows):
    return {field: stats(row[field] for row in rows) for field in V_FIELDS}


def validate_trace(trace, forwards, *, workers):
    io = trace["io"]
    for name in ("reuse_io", "manager_io_loop_reused", "shared_close_submitted",
                 "combine_reserve_start", "reuse_receive_slots"):
        assert io[name] is False
    assert io["closed"] is True and io["closing"] is True
    assert io["receive_pool"] is None
    for name in ("job_count", "worker_loops_created"):
        assert integer(io[name]) == 420
    for name in ("search_clients_created", "search_sessions_created",
                 "control_clients_created"):
        assert integer(io[name]) == 840
    assert 0 < integer(io["control_sessions_created"]) <= 840
    deliveries = integer(io["delivery_count"], minimum=1)
    assert io["registration_count"] == io["unregistration_count"] == deliveries
    assert io["ack_rpc_count"] == io["reserve_rpc_count"] == io["start_rpc_count"] == deliveries
    assert io["combined_rpc_count"] == 0
    assert len(trace["transport"]) == 420
    profiles = []
    for transport in trace["transport"]:
        group = transport["deliveries"]
        assert isinstance(group, list) and len(group) <= 2
        assert len({item["rank"] for item in group}) == len(group)
        assert sum(item["remote_rows"] for item in group) == transport["remote_rows"]
        for item in group:
            assert type(item["rank"]) is int and item["rank"] in (0, 1)
            rows = integer(item["remote_rows"], minimum=1)
            assert rows <= 64 and integer(item["nbytes"], minimum=1) == rows * 512
            assert item["combine_reserve_start"] is item["reuse_receive_slots"] is False
            for name in TIMINGS:
                finite(item[name])
            for name in COUNTERS:
                integer(item[name])
            assert item["physical_register_calls"] == item["physical_unregister_calls"] == 1
            assert item["reserve_calls"] == item["start_calls"] == item["ack_calls"] == 1
            assert item["combined_calls"] == 0
            profiles.append(item)
    assert len(profiles) == deliveries
    for name, counter in COUNTERS.items():
        assert sum(item[name] for item in profiles) == integer(io[counter])
    expected = {(step, layer) for step in range(14) for layer in range(28)}
    layers = trace["layers"]
    assert len(layers) == 392
    assert [(item["step"], item["layer"]) for item in layers] == sorted(expected)
    assert {(item["step"], item["layer"]) for item in trace["transport"][28:]} == expected
    assert [item["consumed"] for item in layers] == sorted(item["consumed"] for item in layers)
    endpoints = []
    for item in layers:
        integer(item["step"])
        integer(item["layer"])
        for name in ("published", "worker_start", "ready", "consumed", "queue_seconds",
                     "service_seconds", "consumer_wait_seconds"):
            finite(item[name])
        assert item["published"] <= item["worker_start"] < item["ready"] <= item["consumed"]
        assert math.isclose(item["queue_seconds"], item["worker_start"] - item["published"], abs_tol=1e-9)
        assert math.isclose(item["service_seconds"], item["ready"] - item["worker_start"], abs_tol=1e-9)
        wait_start = item["consumed"] - item["consumer_wait_seconds"]
        assert type(item["ready_before_consume"]) is bool
        assert item["ready_before_consume"] == (item["ready"] <= wait_start)
        endpoints.extend(((item["worker_start"], 1), (item["ready"], -1)))
    endpoints.sort()
    active = peak = 0
    area = 0.0
    previous = endpoints[0][0]
    for timestamp, delta in endpoints:
        area += active * (timestamp - previous)
        active += delta
        assert 0 <= active <= workers
        peak = max(peak, active)
        previous = timestamp
    assert active == 0 and peak == workers
    service = sum(item["service_seconds"] for item in layers)
    assert math.isclose(area, service, abs_tol=1e-8)
    assert len(forwards) == 15 and [item["step"] for item in forwards] == list(range(15))
    assert forwards[0]["wait_ms"] == 0
    for item in forwards:
        assert 0 <= finite(item["wait_ms"]) <= finite(item["total_ms"])
    forward_wait = sum(item["wait_ms"] for item in forwards[1:])
    layer_wait = sum(item["consumer_wait_seconds"] for item in layers) * 1000
    assert abs(forward_wait - layer_wait) <= 14 * 0.00051
    return {
        "workers": workers, "actual_executor_peak": peak,
        "jobs": io["job_count"], "search_clients": io["search_clients_created"],
        "search_sessions": io["search_sessions_created"], "consumed_callbacks": 392,
        "deliveries": deliveries, "registrations": io["registration_count"],
        "unregistrations": io["unregistration_count"], "acks": io["ack_rpc_count"],
        "profile_bytes": sum(item["nbytes"] for item in profiles),
        "profile_rows": sum(item["remote_rows"] for item in profiles),
        "rows_range": [min(item["remote_rows"] for item in profiles),
                       max(item["remote_rows"] for item in profiles)],
        "exact_profile_bytes_match_rows": True, "closed": True,
        "service_seconds": service,
        "worker_window_seconds": endpoints[-1][0] - endpoints[0][0],
        "mean_service_ms": service * 1000 / 392,
        "mean_queue_ms": mean(item["queue_seconds"] for item in layers) * 1000,
        "mean_kv_wait_ms_per_steady_token": forward_wait / 14,
        "ready_before_consume_fraction": mean(item["ready_before_consume"] for item in layers),
    }


def parse_errors(log):
    suspicious = [line for line in log.splitlines() if re.search(
        r"UNKNOWN|foreign|stale|Traceback|quarant|exception|handoff.*(?:fail|timeout|error)",
        line, re.I)]
    scanners = [line for line in suspicious if '"UNKNOWN / HTTP/1.0" 400' in line]
    errors = [line for line in suspicious if line not in scanners]
    assert not errors, errors
    return {"native_unknown_or_identity_or_handoff_errors": errors,
            "unrelated_invalid_http_method_400": scanners}


def main():
    target = checked_output()
    comparison = read_json("comparison.json")
    assert comparison["comparison"] == "v-workers" and comparison["arms"] == list(ARMS)
    result = {
        "schema_version": 1, "status": "passed",
        "scope": {
            "experiment": "independent config-only 2-to-4-worker ABBA",
            "arm_order": list(ARMS), "formal_requests_per_mode": 4,
            "warmups_per_arm": 2, "formal_requests_per_arm": 2,
            "v_full": "840 search calls/request, including 56 initial-bank calls",
            "v_steady": "784 search calls/request: remove first 56 bootstrap calls from each serialized 840-call request",
            "d_steady": "392 consumed layer callbacks/request; 14 steady tokens; 15 forward timings include initial step with zero KV wait",
            "boundary_proof": "Each arm has four serialized closed/retired requests and exactly 3360 V and D search calls; first 1680 calls are two warmups. Per-request 840 matches 420 jobs times two ranks. Steady784 matches 392 consumed callbacks times two ranks.",
            "means": "Call-weighted means on the named full840 or steady784 scope; D mean service/queue use 392 callbacks. No sum of independent medians.",
            "medians": "Both pooled call median and median of the four request medians are separately named; the frozen V analyzer and report use pooled steady784 call medians. Median of request medians is an additional independent diagnostic.",
            "concurrency": "worker_start to ready callback intervals; includes blocked RPC time, not GPU utilization or OS thread-ID evidence",
            "limits": "Successful serving trace/profile lifecycle audit, not a new native byte-copy test or failure-injection gate. Profiles bind manifest bytes to rows and completed ACK/close counters; raw NIC terminal states are not separately emitted in these traces. Manager-lock/download increases do not prove a particular CUDA-fence cause.",
        },
        "comparison": comparison,
        "recorded_checkout_heads": read_json("checkout_heads.json"),
        "recorded_serving_source_hashes": read_json("source_hashes.json"),
        "requests": {}, "aggregate": {}, "payload_jitter": {}, "input_hashes": {},
    }
    configs = []
    identities = {}
    mode_rows = {mode: {"full840": [], "steady784": [], "requests": []} for mode in ("baseline", "optimized")}
    inputs = ["comparison.json", "checkout_heads.json", "source_hashes.json", "final_gpu_memory.json"]
    for arm in ARMS:
        workers = 4 if arm.startswith("opt") else 2
        config = read_json(arm + "_config.json")
        assert config.pop("workers") == workers
        configs.append(config)
        d_log = (FOLDER / (arm + "_d.log")).read_text(encoding="utf-8")
        v_log = (FOLDER / (arm + "_v.log")).read_text(encoding="utf-8")
        client = read_json(arm + "_warmup.json") + read_json(arm + ".json")
        traces = re.findall(r"PVD Oasis trace rid=(\S+) data=(\{[^\n]+\})", d_log)
        v_stages = [ast.literal_eval(data) for data in re.findall(
            r"PVD V search-batch [^\n]*stage_ms=(\{[^\n]+\})", v_log)]
        search = [dict(bytes=int(row[0]), prepare_ms=float(row[1]), encode_ms=float(row[2]),
                       http_ms=float(row[3]), validate_ms=float(row[4]), total_ms=float(row[5]))
                  for row in D_SEARCH.findall(d_log)]
        assert len(traces) == len(client) == 4
        assert len(v_stages) == len(search) == 3360
        for row in v_stages:
            for field in V_FIELDS:
                finite(row[field])
        arm_rows = []
        for index, ((rid, data), online) in enumerate(zip(traces, client)):
            assert online["status"] == 200 and online["error"] is None
            assert online["completion_tokens"] == 16 and len(online["events"]) == 16
            assert online["events"][0]["event"]["meta_info"]["id"] == rid
            event_times = [finite(item["seconds"]) for item in online["events"]]
            assert event_times == sorted(event_times)
            forwards = [dict(step=int(step), total_ms=float(total), wait_ms=float(wait))
                        for step, total, wait in re.findall(
                            r"PVD Oasis forward rid=" + re.escape(rid) +
                            r" step=(\d+) total_ms=([0-9.]+) layer_wait_ms=([0-9.]+)", d_log)]
            life = validate_trace(json.loads(data), forwards, workers=workers)
            retired = re.findall(r"PVD Oasis retired rid=" + re.escape(rid) +
                                 r" cache_rows=(\d+) layer_wait_ms=([0-9.]+)", d_log)
            assert len(retired) == 1
            life["retired"] = True
            life["retired_cache_rows"] = int(retired[0][0])
            v_full = v_stages[index * 840:(index + 1) * 840]
            v_steady = v_full[56:]
            d_full = search[index * 840:(index + 1) * 840]
            d_steady = d_full[56:]
            assert len(v_full) == len(d_full) == 840 and len(v_steady) == len(d_steady) == 784
            row = {"rid": rid, "case": online["case"], "formal": index >= 2,
                   "lifecycle": life,
                   "v_ms": {"full840": v_stats(v_full), "steady784": v_stats(v_steady)},
                   "d_search_ms": {scope: {name: stats(r[name] for r in rows)
                                           for name in ("total_ms", "http_ms")}
                                   for scope, rows in (("full840", d_full), ("steady784", d_steady))}}
            arm_rows.append(row)
            if index >= 2:
                mode = "optimized" if workers == 4 else "baseline"
                mode_rows[mode]["full840"].extend(v_full)
                mode_rows[mode]["steady784"].extend(v_steady)
                mode_rows[mode]["requests"].append(row)
                identity = (online["prompt_sha256"], online["output_sha256"],
                            tuple(online["events"][-1]["event"]["output_ids"]))
                identities.setdefault(online["case"], []).append(identity)
                result["payload_jitter"].setdefault(str(online["case"]), []).append(
                    {"arm": arm, "profile_bytes": life["profile_bytes"],
                     "profile_rows": life["profile_rows"], "deliveries": life["deliveries"]})
        result["requests"][arm] = {
            "all_requests": arm_rows, "d_log_errors": parse_errors(d_log),
            "v_log_errors": parse_errors(v_log),
            "formal_v_ms": {scope: v_stats([item for request in range(2, 4)
                                           for item in v_stages[request * 840 + (56 if scope == "steady784" else 0):(request + 1) * 840]])
                            for scope in ("full840", "steady784")},
        }
        inputs.extend(arm + suffix for suffix in (
            "_config.json", "_d.log", "_v.log", "_warmup.json", ".json"))
    assert all(config == configs[0] for config in configs)
    assert set(identities) == {99401, 99402}
    assert all(len(rows) == 4 and len(set(rows)) == 1 for rows in identities.values())
    result["same_nonworker_configuration_and_formal_prompt_output_token_identity"] = True
    for mode, data in mode_rows.items():
        requests = data["requests"]
        assert len(requests) == 4
        life = [row["lifecycle"] for row in requests]
        result["aggregate"][mode] = {
            "formal_requests": 4, "actual_executor_peaks": [row["actual_executor_peak"] for row in life],
            "consumed_callbacks": sum(row["consumed_callbacks"] for row in life),
            "jobs": sum(row["jobs"] for row in life),
            "search_sessions": sum(row["search_sessions"] for row in life),
            "registrations": sum(row["registrations"] for row in life),
            "unregistrations": sum(row["unregistrations"] for row in life),
            "acks": sum(row["acks"] for row in life),
            "mean_d_service_ms": mean(row["mean_service_ms"] for row in life),
            "mean_d_queue_ms": mean(row["mean_queue_ms"] for row in life),
            "mean_d_kv_wait_ms_per_steady_token": mean(row["mean_kv_wait_ms_per_steady_token"] for row in life),
            "v_ms": {scope: {name: {**values, "median_of_request_medians": median(
                row["v_ms"][scope][name]["median"] for row in requests)}
                for name, values in v_stats(data[scope]).items()}
                for scope in ("full840", "steady784")},
            "v_calls": {scope: len(data[scope]) for scope in ("full840", "steady784")},
        }
    for case, rows in list(result["payload_jitter"].items()):
        values = [row["profile_bytes"] for row in rows]
        difference = max(values) - min(values)
        result["payload_jitter"][case] = {
            "requests": rows, "min_bytes": min(values), "max_bytes": max(values),
            "difference_bytes": difference, "difference_rows": difference // 512,
            "difference_fraction_of_max": difference / max(values),
            "note": "Same budgets/query counts/output tokens, not identical selected sparse KV payload bytes; no cause assigned.",
        }
    gpu = read_json("final_gpu_memory.json")
    assert set(gpu) == {"p", "v", "d"}
    for value in gpu.values():
        rows = value.splitlines()
        assert len(rows) == 2 and [int(row.split(",")[0]) for row in rows] == [0, 1]
        assert all(int(row.split(",")[1].split()[0]) == 0 for row in rows)
    result["final_gpu_memory"] = gpu
    for name in inputs:
        payload = (FOLDER / name).read_bytes().replace(b"\r\n", b"\n")
        result["input_hashes"][name] = {"sha256": hashlib.sha256(payload).hexdigest(),
                                       "bytes": len(payload), "normalization": "lf"}
    result["parser_sha256_lf"] = hashlib.sha256(Path(__file__).read_bytes().replace(b"\r\n", b"\n")).hexdigest()
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "output": str(target),
                      "all_requests": 16, "formal_requests": 8,
                      "v_full_calls_per_mode": 3360, "v_steady_calls_per_mode": 3136}, ensure_ascii=False))


if __name__ == "__main__":
    main()
